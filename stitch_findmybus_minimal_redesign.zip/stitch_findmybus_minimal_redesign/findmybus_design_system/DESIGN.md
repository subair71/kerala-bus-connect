---
name: FindMyBus Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3e4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#005683'
  on-tertiary: '#ffffff'
  tertiary-container: '#006fa8'
  on-tertiary-container: '#dbecff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg-medium:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-md-medium:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  tabular-time:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system is engineered for public transit navigation across Kerala, where clarity, real-time legibility, and high utility under varied outdoor ambient conditions are paramount. The aesthetic pairs utilitarian transit rigor with a restrained, modern premium finish. 

### Core Ethos
- **Precision Over Decoration**: Every visual element serves a clear orienting purpose. Visual clutter is stripped away in favor of hierarchical typography, structured data grids, and hairline demarcations.
- **Calm & Reassuring**: Commuting in high-density networks can be stressful. The soft slate-tinted canvas and deep coastal teal tones evoke stability, punctuality, and trust.
- **Glanceability Under Sun**: Designed for high contrast and rapid readability on handheld devices outdoors, using deliberate typographic weight steps and dedicated status colors.

### Style Classification
**Modern Precision Minimalist**: Structured around clean structural hairlines, pure white content cards against a subtle slate-tinted canvas, soft micro-elevations, and purposeful accent touches.

## Colors

The palette balances deep nautical teals with crisp slate neutrals, providing high contrast and semantic clarity across bus types (KSRTC Swift, Ordinary, Fast Passenger, Private) and live operational statuses.

### Surface & Background Tokens
- **Canvas Base**: `#F8FAFC` (Slate 50) — Main view canvas offering a soft, glare-reducing warm tint.
- **Surface Level 1**: `#FFFFFF` — Pure white surface for cards, sheets, headers, and floating containers.
- **Surface Level 2 / Muted**: `#F1F5F9` (Slate 100) — Input wells, chip default backgrounds, table headers, and nested blocks.
- **Surface Subtle Border**: `#E2E8F0` (Slate 200) — Hairline structural borders and dividers.
- **Surface Strong Border**: `#CBD5E1` (Slate 300) — Interactive element borders and focused containers.

### Brand & Interactive Tokens
- **Primary Teal**: `#0F766E` (Teal 700) — Primary CTAs, active route lines, active bottom navigation states, key transit nodes.
- **Primary Teal Light**: `#0D9488` (Teal 600) — Secondary brand interactive points, live bus icons.
- **Primary Teal Hover**: `#115E59` (Teal 800) — Pressed/hover states for primary elements.
- **Primary Teal Tint**: `#F0FDFA` (Teal 50) — Selected rows, active tab backgrounds, subtle accent badges.
- **Primary Teal Border Tint**: `#CCFBF1` (Teal 100) — Highlighting borders for active stop sequences and active route cards.

### Typography & Ink Hierarchy
- **Text Primary**: `#0F172A` (Slate 900) — Deep navy charcoal for stop names, timings, headings, and high-emphasis data.
- **Text Secondary**: `#334155` (Slate 700) — Bus types, route descriptors, form field labels.
- **Text Muted**: `#64748B` (Slate 500) — Platform numbers, stop count metadata, helper hints.
- **Text Subtle**: `#94A3B8` (Slate 400) — Placeholder text, disabled labels, tertiary timeline markers.

### Functional Status Tokens
- **Success / On-Time**: Text `#065F46`, Fill `#ECFDF5`, Border `#A7F3D0` (`#059669` for standalone icons and 'Running Today' chips).
- **Warning / Delayed**: Text `#92400E`, Fill `#FFFBEB`, Border `#FDE68A` (`#D97706` for delay notices, route diversions).
- **Destructive / Cancelled**: Text `#991B1B`, Fill `#FEF2F2`, Border `#FECACA` (`#DC2626` for trip cancelled alerts).
- **Neutral / Idle**: Text `#334155`, Fill `#F1F5F9`, Border `#E2E8F0` (`#64748B` for scheduled stops and standard indicators).

## Typography

The type system relies on **Plus Jakarta Sans** across all roles for its balanced geometric structure, open apertures, and crisp rendering in both Malayalam and English transliterated bus stop labels.

### Typographic Hierarchy & Guidelines
- **Timetable Times (`tabular-time`)**: Uses numeric OpenType tabular figures (`font-variant-numeric: tabular-nums`) to ensure vertical alignment of arrival/departure times across multi-row timeline matrices.
- **Headlines (`headline-lg`, `headline-md`)**: Reserved for screen headers ("Ernakulam to Trivandrum") and major modal titles. Tight negative tracking keeps long destination names compact.
- **Body (`body-md`, `body-md-medium`)**: Standardized for route descriptions, bus stop names, and fare information. Medium weight is assigned to the current active stop or primary terminal.
- **Labels & Badges (`label-sm`, `label-md`)**: Scaled down with slightly expanded letter tracking for upper-case and title-case classification chips (e.g., "FAST PASSENGER", "AC LOW FLOOR", "VIA ALAPPUZHA").

## Layout & Spacing

A unified 8pt grid with 4pt baseline substeps governs all layout coordinates, providing predictable cadence across mobile viewports, tablet split-views, and desktop dispatch matrices.

### Breakpoints & Fluid Columns
- **Mobile (< 640px)**: Single-column fluid layout with dynamic sheets. Gutter: `1rem` (16px), Canvas Margin: `1rem` (16px). Bottom sheets snap to 45% and 88% screen heights for live journey tracking.
- **Tablet (640px – 1024px)**: 8-column layout. Split layout pairing map view (4 columns) with schedule timeline (4 columns). Canvas Margin: `1.5rem` (24px).
- **Desktop (> 1024px)**: Max container width constrained to `1200px` (or `1440px` for operations/dashboard views). 12-column layout with `1.5rem` (24px) gutters and `2rem` (32px) margins.

### Component Spacing Rhythm
- **Micro Spacing (`space-xs` = 4px, `space-sm` = 8px)**: Used for distance between stop dots and stop titles, badge internal padding, and icon-to-label gaps.
- **Component Padding (`space-md` = 12px, `space-lg` = 16px)**: Standard inset for bus search input bars, trip schedule cards, and filter chips.
- **Section Rhythm (`space-xl` = 24px)**: Vertical spacing between route segments, search panels, and grouped transit card listings.

## Elevation & Depth

To preserve an airy, precise daylight feel, depth relies primarily on hairline borders paired with ambient, low-opacity shadows. Heavy drop shadows and simulated depth are avoided.

### Surface & Shadow Levels
- **Level 0 (Flat / Canvas)**: `#F8FAFC`. Completely flat base with zero elevation.
- **Level 1 (Card Rest)**: Surface `#FFFFFF`, border `1px solid #E2E8F0`, shadow `0 1px 2px 0 rgba(15, 23, 42, 0.04)`. Used for bus listing items, route summaries, and settings groups.
- **Level 2 (Hover / Active Card)**: Surface `#FFFFFF`, border `1px solid #CBD5E1`, shadow `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`. Used when hovering trip cards or selecting bus stops.
- **Level 3 (Floating Action & Menus)**: Surface `#FFFFFF`, border `1px solid #E2E8F0`, shadow `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`. Used for bottom floating action bars, search dropdown overlays, and map controls.
- **Level 4 (Modals & Bottom Drawers)**: Surface `#FFFFFF`, border-t `1px solid #E2E8F0`, shadow `0 -10px 25px -5px rgba(15, 23, 42, 0.10)`. Used for timetable pull-up sheets and full trip details.

## Shapes

The system implements **Level 2 (Rounded)** curvature. This provides a balance between technical precision and modern ergonomics.

### Curvature Assignments
- **Micro Radii (`0.25rem` / 4px)**: Status dot indicators, badge tags, inline code/route codes.
- **Standard Inset Elements (`0.5rem` / 8px)**: Input fields, buttons, dropdown selects, and standard chip badges.
- **Composite Containers (`1rem` / 16px)**: Timetable cards, trip itinerary overview boxes, route detail modals.
- **Sheet Surfaces (`1.5rem` / 24px top-radius)**: Mobile pull-up bottom sheets and overlay dialogs.
- **Fully Rounded (`9999px` / Pill)**: Bus category toggle pills, live indicator bubbles, circular map control buttons.

## Components

### Buttons
- **Primary**: Background `#0F766E`, text `#FFFFFF`, font weight `600`, height `44px` (mobile touch target), radius `8px`. Hover: `#115E59`. Active: `#0D9488`. Focused with `2px solid #0F766E` offset by 2px.
- **Secondary / Subtle**: Background `#F0FDFA`, border `1px solid #CCFBF1`, text `#0F766E`. Hover: `#E6FFFA`.
- **Outline**: Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#334155`. Hover: border `#CBD5E1`, background `#F8FAFC`.
- **Icon Utility**: Minimalist `40x40px` circular or 8px rounded square with hairline `#E2E8F0` border and slate text `#475569`.

### Chips & Badges
- **Status Chip - Running Today**: Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`. Includes a small `6px` solid `#059669` circle dot on the left.
- **Status Chip - Delay / Note**: Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`.
- **Status Chip - Cancelled**: Background `#FEF2F2`, text `#991B1B`, border `1px solid #FECACA`.
- **Bus Category Badges**: E.g., "Minnal", "Super Fast", "Private". Crisp `#F1F5F9` background with `#334155` text and subtle slate border, uppercase `11px` typography.

### Input Fields & Search Bars
- **Origin / Destination Inputs**: Dual interconnected inputs with a connecting transit line graphic. Background `#FFFFFF`, height `48px`, border `1px solid #CBD5E1`, radius `8px`.
- **Focus State**: Border changes to `#0F766E` with `0 0 0 3px rgba(15, 118, 110, 0.12)` halo ring.
- **Location Swap Action**: Center-positioned circular button (`32x32px`) bridging both inputs, hairline border, rotating animation on tap.

### Timetable & Route Timeline Cards
- **Card Container**: Background `#FFFFFF`, hairline border `1px solid #E2E8F0`, corner radius `12px`, padding `16px`.
- **Timeline Rail**: Vertical `2px` solid line in `#E2E8F0`. Passed stops render with `#CBD5E1` ring dots; upcoming stops render with open white centers; current live bus node renders as a filled `#0F766E` pulsed circle with an outward radar glow.
- **Stop Row Layout**: Left side displays fixed-width tabular arrival/departure time (`#0F172A`, bold `14px`), center features the timeline node, right side displays stop name (`#1E293B`, medium `15px`) and distance/platform tags (`#64748B`, `12px`).

### Lists & Tables
- **Trip Listings**: Clean row demarcations using `#F1F5F9` separator lines without heavy shadows. Alternating hover state uses `#F8FAFC`.
- **Departure Matrix**: Tabular layout with strict vertical alignment for departure time, arrival time, duration, and fare.

### Toggles, Checkboxes & Radios
- **Toggle Switch**: Track width `44px`, height `24px`, background `#E2E8F0` (inactive) transitions to `#0F766E` (active). Thumb is pure white with a `1px` shadow `rgba(0,0,0,0.1)`.
- **Checkboxes**: Corner radius `4px`, border `1.5px solid #CBD5E1`. When checked: fill `#0F766E` with sharp white tick icon.